﻿using System;

class Program
{
    static void Main()
    {
        // Начальные значения
        double a = -1; // Левый конец интервала
        double b = 1; // Правый конец интервала
        double eps = 1e-6; // Точность

        // Метод половинного деления
        double c = (a + b) / 2; // Середина интервала
        while (Math.Abs(b - a) > eps)
        {
            if ((a + c) / 2 + Math.Cos((a + c) / 2) - 1 > 0)
            {
                b = c;
            }
            else
            {
                a = c;
            }
            c = (a + b) / 2;
        }
        Console.WriteLine("Корень методом половинного деления: {0}", c);

        // Метод простой итерации
        double x = 0; // Начальное приближение
        double xPrev;
        double g(double x) // Функция g(x)
        {
            return 1 - Math.Cos(x);
        }
        do
        {
            xPrev = x;
            x = g(xPrev);
        } while (Math.Abs(x - xPrev) > eps);
        Console.WriteLine("Корень методом простой итерации: {0}", x);

        Console.ReadLine();
    }
}