﻿using System;

namespace NonlinearEquationSolver
{
    class Program
    {
        static void Main(string[] args)
        {
            // Определение границ интервала
            double a = -2.0;
            double b = 2.0;

            // Задание точности вычислений
            double eps = 1e-6;

            // Решение уравнения методом половинного деления
            double root_bisection = BisectionMethod(a, b, eps);

            Console.WriteLine($"Метод половинного деления: x = {root_bisection}");

            // Решение уравнения методом простой итерации
            double root_simple_iteration = SimpleIterationMethod(a, b, eps);

            Console.WriteLine($"Метод простой итерации: x = {root_simple_iteration}");

            // Ожидание нажатия клавиши для завершения программы
            Console.WriteLine("Нажмите любую клавишу для выхода");
            Console.ReadKey();
        }

        // Метод половинного деления
        static double BisectionMethod(double a, double b, double eps)
        {
            double c = (a + b) / 2.0;

            while (Math.Abs(b - a) > eps)
            {
                if ((Function(a) * Function(c)) < 0)
                {
                    b = c;
                }
                else
                {
                    a = c;
                }

                c = (a + b) / 2.0;
            }

            return c;
        }

        // Метод простой итерации
        static double SimpleIterationMethod(double a, double b, double eps)
        {
            // Выбор начального приближения
            double x = a;

            while (Math.Abs(Function(x)) > eps)
            {
                // Вычисление следующего приближения
                x = x - Function(x) / FunctionDerivative(x);
            }

            return x;
        }

        // Функция, которую нужно решить
        static double Function(double x)
        {
            return (Math.Pow(x, 3) + 0.1 * Math.Pow(x, 2) - 0.4 * x + 1.5);
        }

        // Производная функции, необходимая для метода простой итерации
        static double FunctionDerivative(double x)
        {
            return (3 * Math.Pow(x, 2) + 0.2 * x - 0.4);
        }
    }
}